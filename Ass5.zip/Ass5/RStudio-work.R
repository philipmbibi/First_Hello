start<-Sys.time()
library(arules)
d<-read.csv("C:\\Users\\MBIBI PHILIP\\Documents\\Assignment5\\datasetR.csv",header = TRUE, sep = ",")
summary(d)
itemsets<-apriori(d, parameter = list(supp=0.1, conf=0.3, minlen = 2, maxlen=4))
as(itemsets,"data.frame");
write(itemsets, file = "C:\\Users\\MBIBI PHILIP\\Documents\\Assignment5\\Rules-T",append =FALSE, sep ="") 
end<-Sys.time()
diff<-end-start
print(diff)