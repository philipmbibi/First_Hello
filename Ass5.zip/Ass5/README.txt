Requirements
1. Download WEKA
2. Download RStudio

On RStudio
install the dependencies 
1. arules
2. arulesVis

Execution Instructions
	-Open Weka 3.8 from start-> double click on it.
	-Select on Explorer
	-then on preprocess interface click on open file
	- locate which file you want to upload, for me it was CSV file, so below specify it as CSV, in other to show all possible csv file based on your located file.
	-click open
	-upload complete, shows below ok, and it display colorful data chart at the right column.
	-proceed to associate button above, and click on it, and click choose to open a new dialog interface for you to choose the supporting rate, as well as the confident rate. For me I set my supporting rate as 0.1, confident rate as 0.3 and number of rules as 100.
	-click ok below.

	Description of steps for R
	-Open RStudio from start-> double click on it.
	-install all packages libraries needed (arules and arulesVis). Check all dependencies field.
	- the interface redisplays �run and console� button above and below
	-then run your code (specify location of your data and assign support rate and confident rate)

